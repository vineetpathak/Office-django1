from django.contrib import admin
from myapp.models import Document
# Register your models here.

# from myapp.models import Topic

admin.site.register(Document)