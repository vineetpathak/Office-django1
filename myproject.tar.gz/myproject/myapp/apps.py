from django.apps import AppConfig
from main.models import *


class MyappConfig(AppConfig):
    name = 'myapp'
